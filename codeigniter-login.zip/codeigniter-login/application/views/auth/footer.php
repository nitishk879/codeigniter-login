<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
    <div class="auth_footer">
        <p class="text-muted text-center">© Svodya - Rise of Sign 2019</p>
    </div>
</div>


<script src="<?php echo base_url("assets/vendors/js/core.js"); ?>"></script>
<script src="<?php echo base_url("assets/vendors/js/vendor.addons.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/template.js"); ?>"></script>
</body>
</html>